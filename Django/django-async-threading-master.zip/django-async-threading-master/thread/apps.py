from django.apps import AppConfig


class ThreadConfig(AppConfig):
    name = 'thread'
